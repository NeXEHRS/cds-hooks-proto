package jp.cpcnexehrs.cds.hooks.client.form;

public class DiscoveryForm {

    private String responseBody;

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

}
